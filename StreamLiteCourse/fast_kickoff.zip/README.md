# ML-based tool for Iris classification problem

Dataset used: https://www.kaggle.com/datasets/uciml/iris

- wrapped into Streamlit App
- basic logging with Loguru
